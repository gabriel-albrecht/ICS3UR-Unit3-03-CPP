// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This is another number guessing program

#include <iostream>
#include <random>

int main() {
    std::default_random_engine generator;
    std::uniform_int_distribution<int> distribution(0, 9);
    int value = distribution(generator);
    int number;

    // input
    std::cout << "Pick a number between 0-9: ";
    std::cin >> number;
    std::cout << "" << std::endl;

    // process
    if (number == value) {
        // output
        std::cout << "Congratulations! You picked the right number!";
    }

    if (number != value) {
        // output
        std::cout << "Wrong number! Try again.";
    }
}
